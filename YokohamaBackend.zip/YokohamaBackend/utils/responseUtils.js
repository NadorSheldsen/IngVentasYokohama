// Helper utilities for sending HTTP responses in a user-friendly way
// Always log the technical error on the server, but send only a
// concise, user-friendly message to the client.
module.exports.handleServerError = function (res, userMessage, error, status = 500) {
  // Log full error server-side for debugging
  try {
    console.error(error);
  } catch (logErr) {
    // If console.error fails for any reason, keep going
    // (this is extremely unlikely)
    console.error('Error while logging error:', logErr);
  }

  // Send only the user-facing message to the client. This avoids
  // leaking stack traces, raw DB errors or JSON objects to end users.
  try {
    return res.status(status).json({ message: userMessage });
  } catch (sendErr) {
    // If sending the JSON fails, fall back to a minimal response.
    console.error('Failed to send error response:', sendErr);
    return res.status(500).json({ message: 'Ocurrió un error en el servidor' });
  }
};

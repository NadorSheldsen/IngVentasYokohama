const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { handleServerError } = require('../utils/responseUtils');

// GET - Obtener todos los vehículos de inspección
router.get('/', async (req, res) => {
    try {
        const [rows] = await db.execute(`
            SELECT 
                vi.idVehiculoInspeccion,
                vi.pruebasinspeccion_idPruebaInspeccion,
                vi.TipoVehiculos_idTipoVehiculos,
                vi.VehiculoInspeccionNo,
                -- Include stored coordinates when available
                vi.VehiculosInspeccionLat AS latitude,
                vi.VehiculosInspeccionLon AS longitude,
                pi.PruebaInspeccionTitulo,
                tv.TipoVehiculosNombre
            FROM vehiculosinspeccion vi
            LEFT JOIN pruebasinspeccion pi ON vi.pruebasinspeccion_idPruebaInspeccion = pi.idPruebaInspeccion
            LEFT JOIN TipoVehiculos tv ON vi.TipoVehiculos_idTipoVehiculos = tv.idTipoVehiculos
            ORDER BY vi.VehiculoInspeccionNo
        `);
        res.json(rows);
    } catch (error) {
        handleServerError(res, 'Error al obtener los vehículos de inspección', error);
    }
});

// GET - Obtener vehículos por prueba de inspección
router.get('/prueba/:pruebaId', async (req, res) => {
    try {
        const { pruebaId } = req.params;
        const [rows] = await db.execute(`
            SELECT 
                vi.idVehiculoInspeccion,
                vi.pruebasinspeccion_idPruebaInspeccion,
                vi.TipoVehiculos_idTipoVehiculos,
                vi.VehiculoInspeccionNo,
                -- Include stored coordinates when available
                vi.VehiculosInspeccionLat AS latitude,
                vi.VehiculosInspeccionLon AS longitude,
                pi.PruebaInspeccionTitulo,
                tv.TipoVehiculosNombre
            FROM vehiculosinspeccion vi
            LEFT JOIN pruebasinspeccion pi ON vi.pruebasinspeccion_idPruebaInspeccion = pi.idPruebaInspeccion
            LEFT JOIN TipoVehiculos tv ON vi.TipoVehiculos_idTipoVehiculos = tv.idTipoVehiculos
            WHERE vi.pruebasinspeccion_idPruebaInspeccion = ?
            ORDER BY vi.VehiculoInspeccionNo
        `, [pruebaId]);
        res.json(rows);
    } catch (error) {
        handleServerError(res, 'Error al obtener los vehículos de inspección', error);
    }
});

// GET - Obtener un vehículo de inspección específico
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const [rows] = await db.execute(`
            SELECT 
                vi.idVehiculoInspeccion,
                vi.pruebasinspeccion_idPruebaInspeccion,
                vi.TipoVehiculos_idTipoVehiculos,
                vi.VehiculoInspeccionNo,
                -- Include stored coordinates when available
                vi.VehiculosInspeccionLat AS latitude,
                vi.VehiculosInspeccionLon AS longitude,
                pi.PruebaInspeccionTitulo,
                tv.TipoVehiculosNombre
            FROM vehiculosinspeccion vi
            LEFT JOIN pruebasinspeccion pi ON vi.pruebasinspeccion_idPruebaInspeccion = pi.idPruebaInspeccion
            LEFT JOIN TipoVehiculos tv ON vi.TipoVehiculos_idTipoVehiculos = tv.idTipoVehiculos
            WHERE vi.idVehiculoInspeccion = ?
        `, [id]);
        
        if (rows.length === 0) {
            return res.status(404).json({ message: 'Vehículo de inspección no encontrado' });
        }
        
        res.json(rows[0]);
    } catch (error) {
        handleServerError(res, 'Error al obtener el vehículo de inspección', error);
    }
});

// POST - Crear nuevo vehículo de inspección
router.post('/', async (req, res) => {
    try {
        const { 
            pruebasinspeccion_idPruebaInspeccion, 
            TipoVehiculos_idTipoVehiculos, 
            VehiculoInspeccionNo,
            latitude,
            longitude
        } = req.body;
        
        if (!pruebasinspeccion_idPruebaInspeccion || !TipoVehiculos_idTipoVehiculos || !VehiculoInspeccionNo) {
            return res.status(400).json({ message: 'Todos los campos son requeridos' });
        }

        // Prevent duplicate vehicle number inside the same prueba de inspección
        const [duplicate] = await db.execute(
            'SELECT idVehiculoInspeccion FROM vehiculosinspeccion WHERE pruebasinspeccion_idPruebaInspeccion = ? AND VehiculoInspeccionNo = ? LIMIT 1',
            [pruebasinspeccion_idPruebaInspeccion, VehiculoInspeccionNo]
        );
        if (duplicate && duplicate.length > 0) {
            const msg = 'Ya existe un vehículo con ese número en la prueba de inspección';
            res.set('X-Error-Message', msg);
            return res.status(409).json({ message: msg });
        }

        const [result] = await db.execute(`
            INSERT INTO vehiculosinspeccion (
                pruebasinspeccion_idPruebaInspeccion, 
                TipoVehiculos_idTipoVehiculos, 
                VehiculoInspeccionNo,
                VehiculosInspeccionLat,
                VehiculosInspeccionLon
            )
            VALUES (?, ?, ?, ?, ?)
        `, [pruebasinspeccion_idPruebaInspeccion, TipoVehiculos_idTipoVehiculos, VehiculoInspeccionNo, latitude || null, longitude || null]);

        // Obtener el vehículo creado
        const [rows] = await db.execute(`
            SELECT 
                vi.idVehiculoInspeccion,
                vi.pruebasinspeccion_idPruebaInspeccion,
                vi.TipoVehiculos_idTipoVehiculos,
                vi.VehiculoInspeccionNo,
                -- Include stored coordinates when available
                vi.VehiculosInspeccionLat AS latitude,
                vi.VehiculosInspeccionLon AS longitude,
                pi.PruebaInspeccionTitulo,
                tv.TipoVehiculosNombre
            FROM vehiculosinspeccion vi
            LEFT JOIN pruebasinspeccion pi ON vi.pruebasinspeccion_idPruebaInspeccion = pi.idPruebaInspeccion
            LEFT JOIN TipoVehiculos tv ON vi.TipoVehiculos_idTipoVehiculos = tv.idTipoVehiculos
            WHERE vi.idVehiculoInspeccion = ?
        `, [result.insertId]);

        // Also try to update the master Vehiculos row (if exists)
        try {
            if (latitude || longitude) {
                await db.execute('UPDATE Vehiculos SET VehiculosLatitude = ?, VehiculosLongitude = ? WHERE VehiculosNumero = ? AND TipoVehiculos_idTipoVehiculos = ? LIMIT 1', [latitude || null, longitude || null, VehiculoInspeccionNo, TipoVehiculos_idTipoVehiculos]);
            }
        } catch (e) {
            // ignore
        }

        res.status(201).json(rows[0]);
    } catch (error) {
        handleServerError(res, 'Error al crear el vehículo de inspección', error);
    }
});

// PUT - Actualizar vehículo de inspección
router.put('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { 
            TipoVehiculos_idTipoVehiculos, 
            VehiculoInspeccionNo,
            latitude,
            longitude
        } = req.body;

        if (!TipoVehiculos_idTipoVehiculos || !VehiculoInspeccionNo) {
            return res.status(400).json({ message: 'Tipo de vehículo y número son requeridos' });
        }

        // Prevent changing to a number that already exists in the same prueba
        const [existing] = await db.execute(
            'SELECT idVehiculoInspeccion FROM vehiculosinspeccion WHERE pruebasinspeccion_idPruebaInspeccion = (SELECT pruebasinspeccion_idPruebaInspeccion FROM vehiculosinspeccion WHERE idVehiculoInspeccion = ?) AND VehiculoInspeccionNo = ? AND idVehiculoInspeccion != ? LIMIT 1',
            [id, VehiculoInspeccionNo, id]
        );
        if (existing && existing.length > 0) {
            const msg = 'Ya existe otro vehículo con ese número en la misma prueba de inspección';
            res.set('X-Error-Message', msg);
            return res.status(409).json({ message: msg });
        }

        const [result] = await db.execute(`
            UPDATE vehiculosinspeccion 
            SET TipoVehiculos_idTipoVehiculos = ?, VehiculoInspeccionNo = ?, VehiculosInspeccionLat = ?, VehiculosInspeccionLon = ?
            WHERE idVehiculoInspeccion = ?
        `, [TipoVehiculos_idTipoVehiculos, VehiculoInspeccionNo, latitude || null, longitude || null, id]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Vehículo de inspección no encontrado' });
        }

        // Obtener el vehículo actualizado
        const [rows] = await db.execute(`
            SELECT 
                vi.idVehiculoInspeccion,
                vi.pruebasinspeccion_idPruebaInspeccion,
                vi.TipoVehiculos_idTipoVehiculos,
                vi.VehiculoInspeccionNo,
                pi.PruebaInspeccionTitulo,
                tv.TipoVehiculosNombre
            FROM vehiculosinspeccion vi
            LEFT JOIN pruebasinspeccion pi ON vi.pruebasinspeccion_idPruebaInspeccion = pi.idPruebaInspeccion
            LEFT JOIN TipoVehiculos tv ON vi.TipoVehiculos_idTipoVehiculos = tv.idTipoVehiculos
            WHERE vi.idVehiculoInspeccion = ?
        `, [id]);

        // Also try to update the master Vehiculos row (if exists)
        try {
            if (latitude || longitude) {
                await db.execute('UPDATE Vehiculos SET VehiculosLatitude = ?, VehiculosLongitude = ? WHERE VehiculosNumero = ? AND TipoVehiculos_idTipoVehiculos = ? LIMIT 1', [latitude || null, longitude || null, VehiculoInspeccionNo, TipoVehiculos_idTipoVehiculos]);
            }
        } catch (e) {
            // ignore
        }

        res.json(rows[0]);
    } catch (error) {
        handleServerError(res, 'Error al actualizar el vehículo de inspección', error);
    }
});

// DELETE - Eliminar vehículo de inspección
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;

        const [result] = await db.execute(`
            DELETE FROM vehiculosinspeccion WHERE idVehiculoInspeccion = ?
        `, [id]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Vehículo de inspección no encontrado' });
        }

        res.json({ message: 'Vehículo de inspección eliminado correctamente' });
    } catch (error) {
        handleServerError(res, 'Error al eliminar el vehículo de inspección', error);
    }
});

module.exports = router;

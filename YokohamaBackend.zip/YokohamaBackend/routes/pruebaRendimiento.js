const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { handleServerError } = require('../utils/responseUtils');

// GET all pruebas de rendimiento with related data
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT pr.*, v.VehiculosNumero,
             pr.PruebaRendimientoLat AS latitude,
             pr.PruebaRendimientoLon AS longitude
      FROM PruebaRendimiento pr
      JOIN Vehiculos v ON pr.Vehiculos_idVehiculos = v.idVehiculos
    `);
    res.json(rows);
  } catch (error) {
    handleServerError(res, 'Error al obtener las pruebas de rendimiento', error);
  }
});

// GET a specific prueba de rendimiento by ID
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await db.query(`
            SELECT pr.*, v.VehiculosNumero,
              pr.PruebaRendimientoLat AS latitude,
              pr.PruebaRendimientoLon AS longitude
            FROM PruebaRendimiento pr
      JOIN Vehiculos v ON pr.Vehiculos_idVehiculos = v.idVehiculos
      WHERE pr.idPruebaRendimiento = ?
    `, [req.params.id]);
    
    if (rows.length === 0) {
      return res.status(404).json({ message: 'Prueba de rendimiento no encontrada' });
    }
    
    res.json(rows[0]);
  } catch (error) {
    handleServerError(res, 'Error al obtener la prueba de rendimiento', error);
  }
});

// GET latest prueba de rendimiento for a given vehiculo
router.get('/vehiculo/:vehiculoId/ultimo', async (req, res) => {
  try {
    const vehiculoId = req.params.vehiculoId;
    const [rows] = await db.query(
      'SELECT * FROM PruebaRendimiento WHERE Vehiculos_idVehiculos = ? ORDER BY idPruebaRendimiento DESC LIMIT 1',
      [vehiculoId]
    );

    if (rows.length === 0) {
      // Return explicit null so client can detect no previous prueba
      return res.json(null);
    }

    res.json(rows[0]);
  } catch (error) {
    handleServerError(res, 'Error al obtener la última prueba de rendimiento para el vehículo', error);
  }
});

// POST a new prueba de rendimiento
router.post('/', async (req, res) => {
  console.log('Received single prueba de rendimiento request');
  try {
    const { Vehiculos_idVehiculos, PruebaRendimientoFecha, PruebaRendimientoOdometro, latitude, longitude } = req.body;

    // Insertar la nueva prueba (incluyendo lat/lon si vienen)
    const [result] = await db.query(
      'INSERT INTO PruebaRendimiento (Vehiculos_idVehiculos, PruebaRendimientoFecha, PruebaRendimientoOdometro, PruebaRendimientoLat, PruebaRendimientoLon) VALUES (?, ?, ?, ?, ?)',
      [Vehiculos_idVehiculos, PruebaRendimientoFecha, PruebaRendimientoOdometro, latitude || null, longitude || null]
    );

    // Consultar el registro recién creado
    const [rows] = await db.query(
      'SELECT * FROM PruebaRendimiento WHERE idPruebaRendimiento = ?',
      [result.insertId]
    );

    // Responder con el objeto completo
    res.status(201).json(rows[0]);
  } catch (error) {
    handleServerError(res, 'Error al crear la prueba de rendimiento', error);
  }
});

// PUT/UPDATE a prueba de rendimiento
router.put('/:id', async (req, res) => {
  try {
    const { Vehiculos_idVehiculos, PruebaRendimientoFecha, PruebaRendimientoOdometro, latitude, longitude } = req.body;
    
    const [result] = await db.query(
      'UPDATE PruebaRendimiento SET Vehiculos_idVehiculos = ?, PruebaRendimientoFecha = ?, PruebaRendimientoOdometro = ?, PruebaRendimientoLat = ?, PruebaRendimientoLon = ? WHERE idPruebaRendimiento = ?',
      [Vehiculos_idVehiculos, PruebaRendimientoFecha, PruebaRendimientoOdometro, latitude || null, longitude || null, req.params.id]
    );
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Prueba de rendimiento no encontrada' });
    }
    
    res.json({ message: 'Prueba de rendimiento actualizada correctamente' });
  } catch (error) {
    handleServerError(res, 'Error al actualizar la prueba de rendimiento', error);
  }
});

// DELETE a prueba de rendimiento
router.delete('/:id', async (req, res) => {
  try {
    const [result] = await db.query('DELETE FROM PruebaRendimiento WHERE idPruebaRendimiento = ?', [req.params.id]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Prueba de rendimiento no encontrada' });
    }
    
    res.json({ message: 'Prueba de rendimiento eliminada correctamente' });
  } catch (error) {
    handleServerError(res, 'Error al eliminar la prueba de rendimiento', error);
  }
});

module.exports = router;

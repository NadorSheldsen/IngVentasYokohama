const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { handleServerError } = require('../utils/responseUtils');

// GET all pruebas desecho
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM PruebasDesecho');
    res.json(rows);
  } catch (error) {
    handleServerError(res, 'Error al obtener las pruebas de desecho', error);
  }
});

// GET a specific prueba desecho by ID
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM PruebasDesecho WHERE idPruebasDesecho = ?', [req.params.id]);
    if (rows.length === 0) {
      return res.status(404).json({ message: 'Prueba de desecho no encontrada' });
    }
    res.json(rows[0]);
  } catch (error) {
    handleServerError(res, 'Error al obtener la prueba de desecho', error);
  }
});

// POST a new prueba desecho
router.post('/', async (req, res) => {
  try {
    const { PruebasDesechoNombre, PruebasDesechoFecha } = req.body;
    
    const [result] = await db.query(
      'INSERT INTO PruebasDesecho (PruebasDesechoNombre, PruebasDesechoFecha) VALUES (?, ?)',
      [PruebasDesechoNombre, PruebasDesechoFecha]
    );
    
    // Return the newly created row so clients receive the full object
    const [rows] = await db.query('SELECT * FROM PruebasDesecho WHERE idPruebasDesecho = ?', [result.insertId]);
    if (rows.length === 0) {
      return res.status(201).json({ message: 'Prueba desecho creada, pero no se pudo recuperar el registro' });
    }
    res.status(201).json(rows[0]);
  } catch (error) {
    handleServerError(res, 'Error al crear la prueba de desecho', error);
  }
});

// PUT/UPDATE a prueba desecho
router.put('/:id', async (req, res) => {
  try {
    const { PruebasDesechoNombre, PruebasDesechoFecha } = req.body;
    
    const [result] = await db.query(
      'UPDATE PruebasDesecho SET PruebasDesechoNombre = ?, PruebasDesechoFecha = ? WHERE idPruebasDesecho = ?',
      [PruebasDesechoNombre, PruebasDesechoFecha, req.params.id]
    );
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Prueba de desecho no encontrada' });
    }
    
    res.json({ message: 'Prueba de desecho actualizada correctamente' });
  } catch (error) {
    handleServerError(res, 'Error al actualizar la prueba de desecho', error);
  }
});

// DELETE a prueba desecho
router.delete('/:id', async (req, res) => {
  try {
    const [result] = await db.query('DELETE FROM PruebasDesecho WHERE idPruebasDesecho = ?', [req.params.id]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Prueba de desecho no encontrada' });
    }
    
    res.json({ message: 'Prueba de desecho eliminada correctamente' });
  } catch (error) {
    handleServerError(res, 'Error al eliminar la prueba de desecho', error);
  }
});

module.exports = router;

const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { handleServerError } = require('../utils/responseUtils');

// GET all vehiculos with related data
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT v.*, TO_BASE64(v.VehiculosImagen) AS VehiculosImagen, f.FlotasNombre, t.TipoVehiculosNombre 
      FROM Vehiculos v
      JOIN Flotas f ON v.Flotas_idFlotas = f.idFlotas
      JOIN TipoVehiculos t ON v.TipoVehiculos_idTipoVehiculos = t.idTipoVehiculos
    `);
    // Ensure any binary/image-like columns are returned as base64 strings
    const processed = rows.map(r => {
      try {
        Object.keys(r).forEach(key => {
          const low = String(key).toLowerCase();
          if (low.includes('vehiculos') && low.includes('imagen')) {
            try {
              const val = r[key];
              let b64 = null;
              if (Buffer.isBuffer(val)) {
                b64 = val.toString('base64');
                console.log(`[vehiculos] converted buffer for key=${key}, length=${b64.length}`);
              } else if (typeof val === 'object' && val && Array.isArray(val.data)) {
                b64 = Buffer.from(val.data).toString('base64');
                console.log(`[vehiculos] converted object.data for key=${key}, length=${b64.length}`);
              }
              // set canonical property name expected by the client
              if (b64 !== null) {
                r['VehiculosImagen'] = b64;
              }
            } catch (e) {
              // ignore conversion error for specific key
            }
          }
        });
      } catch (e) {
        // ignore conversion errors, leave original
      }
      return r;
    });
    res.json(processed);
  } catch (error) {
    handleServerError(res, 'Error al obtener los vehículos', error);
  }
});

// GET a specific vehiculo by ID
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT v.*, TO_BASE64(v.VehiculosImagen) AS VehiculosImagen, f.FlotasNombre, t.TipoVehiculosNombre 
      FROM Vehiculos v
      JOIN Flotas f ON v.Flotas_idFlotas = f.idFlotas
      JOIN TipoVehiculos t ON v.TipoVehiculos_idTipoVehiculos = t.idTipoVehiculos
      WHERE v.idVehiculos = ?
    `, [req.params.id]);
    
    if (rows.length === 0) {
      return res.status(404).json({ message: 'Vehículo no encontrado' });
    }
    // Convert image buffer to base64 if necessary
    const row = rows[0];
    try {
      Object.keys(row).forEach(key => {
        const low = String(key).toLowerCase();
        if (low.includes('vehiculos') && low.includes('imagen')) {
          const val = row[key];
          try {
            let b64 = null;
            if (Buffer.isBuffer(val)) {
              b64 = val.toString('base64');
              console.log(`[vehiculos] converted buffer for single row key=${key}, length=${b64.length}`);
            } else if (typeof val === 'object' && val && Array.isArray(val.data)) {
              b64 = Buffer.from(val.data).toString('base64');
              console.log(`[vehiculos] converted object.data for single row key=${key}, length=${b64.length}`);
            }
            if (b64 !== null) {
              row['VehiculosImagen'] = b64;
            }
          } catch (e) {
            // ignore conversion errors
          }
        }
      });
    } catch (e) {
      // ignore
    }

    res.json(row);
  } catch (error) {
    handleServerError(res, 'Error al obtener el vehículo', error);
  }
});

// POST a new vehiculo
router.post('/', async (req, res) => {
  try {
    const { 
      Flotas_idFlotas, 
      VehiculosNumero, 
      TipoVehiculos_idTipoVehiculos, 
      VehiculosOdometro, 
      VehiculosImagen 
    } = req.body;
    // Debug: log incoming image size (base64 length)
    try {
      console.log(`[vehiculos] Create request - VehiculosNumero=${VehiculosNumero}, VehiculosImagen length=${VehiculosImagen ? VehiculosImagen.length : 0}`);
    } catch (e) {
      // ignore logging errors
    }
    
    // Prevent duplicate vehicle number within the same flota
    const [existing] = await db.query(
      'SELECT idVehiculos FROM Vehiculos WHERE Flotas_idFlotas = ? AND VehiculosNumero = ? LIMIT 1',
      [Flotas_idFlotas, VehiculosNumero]
    );
    if (existing && existing.length > 0) {
      const msg = 'Vehículo con ese número ya existe en la flota';
      // Some fronting hosting providers replace the response body with an HTML
      // error page but preserve headers. Expose a machine-readable header so
      // clients can prefer it when the body is lost/rewritten by the proxy.
      res.set('X-Error-Message', msg);
      return res.status(409).json({ message: msg });
    }

    const [result] = await db.query(
      'INSERT INTO Vehiculos (Flotas_idFlotas, VehiculosNumero, TipoVehiculos_idTipoVehiculos, VehiculosOdometro, VehiculosImagen) VALUES (?, ?, ?, ?, ?)',
      [Flotas_idFlotas, VehiculosNumero, TipoVehiculos_idTipoVehiculos, VehiculosOdometro, VehiculosImagen]
    );

    // If the schema includes VehiculosOdometroRegistro, set it to the initial odometer value
    // for the newly created vehicle. Wrap in try/catch so code works even when column is absent.
    try {
      await db.query(
        'UPDATE Vehiculos SET VehiculosOdometroRegistro = ? WHERE idVehiculos = ? AND (VehiculosOdometroRegistro IS NULL OR VehiculosOdometroRegistro = 0)',
        [VehiculosOdometro, result.insertId]
      );
    } catch (e) {
      // ignore: column may not exist in older schemas
    }

    // Try to return the freshly created vehiculo so clients can deserialize directly
    try {
      const [rows] = await db.query(`
        SELECT v.*, TO_BASE64(v.VehiculosImagen) AS VehiculosImagen, f.FlotasNombre, t.TipoVehiculosNombre 
        FROM Vehiculos v
        JOIN Flotas f ON v.Flotas_idFlotas = f.idFlotas
        JOIN TipoVehiculos t ON v.TipoVehiculos_idTipoVehiculos = t.idTipoVehiculos
        WHERE v.idVehiculos = ?
      `, [result.insertId]);

      if (rows.length === 0) {
        return res.status(201).json({ message: 'Vehiculo created', id: result.insertId });
      }

      // Ensure image field is base64 string if necessary (same processing as GET /:id)
      const row = rows[0];
      try {
        Object.keys(row).forEach(key => {
          const low = String(key).toLowerCase();
          if (low.includes('vehiculos') && low.includes('imagen')) {
            const val = row[key];
            try {
              let b64 = null;
              if (Buffer.isBuffer(val)) {
                b64 = val.toString('base64');
              } else if (typeof val === 'object' && val && Array.isArray(val.data)) {
                b64 = Buffer.from(val.data).toString('base64');
              }
              if (b64 !== null) {
                row['VehiculosImagen'] = b64;
              }
            } catch (e) {
              // ignore conversion errors
            }
          }
        });
      } catch (e) {
        // ignore
      }

      return res.status(201).json(row);
    } catch (fetchError) {
      console.error('Error fetching created vehiculo:', fetchError);
      return res.status(201).json({ message: 'Vehiculo created', id: result.insertId });
    }
  } catch (error) {
    handleServerError(res, 'Error al crear el vehículo', error);
  }
});

// PUT/UPDATE a vehiculo
router.put('/:id', async (req, res) => {
  try {
    const { 
      Flotas_idFlotas, 
      VehiculosNumero, 
      TipoVehiculos_idTipoVehiculos, 
      VehiculosOdometro, 
      VehiculosImagen 
    } = req.body;
    
    const [result] = await db.query(
      'UPDATE Vehiculos SET Flotas_idFlotas = ?, VehiculosNumero = ?, TipoVehiculos_idTipoVehiculos = ?, VehiculosOdometro = ?, VehiculosImagen = ? WHERE idVehiculos = ?',
      [Flotas_idFlotas, VehiculosNumero, TipoVehiculos_idTipoVehiculos, VehiculosOdometro, VehiculosImagen, req.params.id]
    );
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Vehículo no encontrado' });
    }
    
    res.json({ message: 'Vehículo actualizado correctamente' });
  } catch (error) {
    handleServerError(res, 'Error al actualizar el vehículo', error);
  }
});

// PUT: set/clear the VehiculosPTerminada flag for a vehicle
router.put('/:id/terminada', async (req, res) => {
  try {
    const { VehiculosPTerminada, terminada } = req.body;
    // Accept either numeric VehiculosPTerminada or boolean 'terminada' in the body
    let flag = null;
    if (typeof VehiculosPTerminada !== 'undefined') {
      flag = Number(VehiculosPTerminada) === 1 ? 1 : 0;
    } else if (typeof terminada !== 'undefined') {
      flag = terminada ? 1 : 0;
    } else {
      return res.status(400).json({ message: 'Se debe enviar VehiculosPTerminada o terminada en el cuerpo' });
    }

    const [result] = await db.query('UPDATE Vehiculos SET VehiculosPTerminada = ? WHERE idVehiculos = ?', [flag, req.params.id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Vehículo no encontrado' });
    }

    // Return updated row
    const [rows] = await db.query(`SELECT v.*, TO_BASE64(v.VehiculosImagen) AS VehiculosImagen, f.FlotasNombre, t.TipoVehiculosNombre FROM Vehiculos v JOIN Flotas f ON v.Flotas_idFlotas = f.idFlotas JOIN TipoVehiculos t ON v.TipoVehiculos_idTipoVehiculos = t.idTipoVehiculos WHERE v.idVehiculos = ?`, [req.params.id]);
    if (rows.length === 0) return res.json({ message: 'Vehículo actualizado' });
    res.json(rows[0]);
  } catch (error) {
    handleServerError(res, 'Error al actualizar VehiculosPTerminada', error);
  }
});

// DELETE a vehiculo
router.delete('/:id', async (req, res) => {
  try {
    const [result] = await db.query('DELETE FROM Vehiculos WHERE idVehiculos = ?', [req.params.id]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Vehículo no encontrado' });
    }
    
    res.json({ message: 'Vehículo eliminado correctamente' });
  } catch (error) {
    handleServerError(res, 'Error al eliminar el vehículo', error);
  }
});

// GET all llantas for a specific vehiculo
router.get('/:id/llantas', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT lv.*, l.LlantasMarca, l.LlantasModelo, l.LlantasMedida
      FROM LlantasVehiculos lv
      JOIN Llantas l ON lv.Llantas_idLlantas = l.idLlantas
      WHERE lv.Vehiculos_idVehiculos = ?
    `, [req.params.id]);
    
    res.json(rows);
  } catch (error) {
    handleServerError(res, 'Error al obtener las llantas del vehículo', error);
  }
});

module.exports = router;

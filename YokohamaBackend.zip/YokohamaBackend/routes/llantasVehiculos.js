const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { handleServerError } = require('../utils/responseUtils');

// GET all llantas vehiculos with related data
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT lv.*, l.LlantasMarca, l.LlantasModelo, l.LlantasMedida, l.LlantasMm, l.LlantasPrecio,
             v.VehiculosNumero
      FROM LlantasVehiculos lv
      JOIN Llantas l ON lv.Llantas_idLlantas = l.idLlantas
      JOIN Vehiculos v ON lv.Vehiculos_idVehiculos = v.idVehiculos
    `);
    res.json(rows);
  } catch (error) {
    handleServerError(res, 'Error al obtener las llantas de vehículo', error);
  }
});

// GET llantas vehiculos by vehiculo ID
router.get('/vehiculo/:vehiculoId', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT lv.*, l.LlantasMarca, l.LlantasModelo, l.LlantasMedida, l.LlantasMm, l.LlantasPrecio
      FROM LlantasVehiculos lv
      JOIN Llantas l ON lv.Llantas_idLlantas = l.idLlantas
      WHERE lv.Vehiculos_idVehiculos = ?
    `, [req.params.vehiculoId]);
    
    res.json(rows);
  } catch (error) {
    handleServerError(res, 'Error al obtener las llantas del vehículo', error);
  }
});

// POST a new llanta vehiculo
router.post('/', async (req, res) => {
  console.log('Received single llanta vehiculo request');
  try {
    const { 
      Llantas_idLlantas,
      Vehiculos_idVehiculos,
      LlantasVehiculosNoQuemado,
      LlantasVehiculosPresion,
      LlantasVehiculosPrecio,
      LlantasVehiculosPiso,
      LlantasVehiculosMM1,
      LlantasVehiculosMM2,
      LlantasVehiculosMM3,
      LlantasVehiculosMM4
    } = req.body;

    const [result] = await db.query(
      `INSERT INTO LlantasVehiculos (
        Llantas_idLlantas,
        Vehiculos_idVehiculos,
        LlantasVehiculosNoQuemado,
        LlantasVehiculosPresion,
        LlantasVehiculosPrecio,
        LlantasVehiculosPiso,
        LlantasVehiculosMM1,
        LlantasVehiculosMM2,
        LlantasVehiculosMM3,
        LlantasVehiculosMM4
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        Llantas_idLlantas,
        Vehiculos_idVehiculos,
        LlantasVehiculosNoQuemado,
        LlantasVehiculosPresion,
        LlantasVehiculosPrecio,
        LlantasVehiculosPiso,
        LlantasVehiculosMM1,
        LlantasVehiculosMM2,
        LlantasVehiculosMM3,
        LlantasVehiculosMM4
      ]
    );
    
    res.status(201).json({ 
      message: 'Llanta vehiculo created successfully', 
      id: result.insertId 
    });
  } catch (error) {
    handleServerError(res, 'Error al crear la llanta del vehículo', error);
  }
});

router.post('/batch', async (req, res) => {
  console.log('Received batch request');
  console.log(req.body);

  const llantas = req.body; 
  if (!Array.isArray(llantas) || llantas.length === 0) {
    return res.status(400).json({ message: 'Debe enviar un arreglo de llantas' });
  }
  const results = [];
  const errors = [];
    for (const data of llantas) {
    try {
        // Check duplicate per item
        const [already] = await connection.query('SELECT idLlantasVehiculos FROM LlantasVehiculos WHERE Vehiculos_idVehiculos = ? AND Llantas_idLlantas = ? LIMIT 1', [data.Vehiculos_idVehiculos, data.Llantas_idLlantas]);
        if (already && already.length > 0) {
          errors.push({ error: 'Llanta ya asignada', data });
          continue;
        }
      const [result] = await db.query(
        `INSERT INTO LlantasVehiculos (
          Llantas_idLlantas,
          Vehiculos_idVehiculos,
          LlantasVehiculosNoQuemado,
          LlantasVehiculosPresion,
          LlantasVehiculosPrecio,
          LlantasVehiculosPiso,
          LlantasVehiculosMM1,
          LlantasVehiculosMM2,
          LlantasVehiculosMM3,
          LlantasVehiculosMM4
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          data.Llantas_idLlantas,
          data.Vehiculos_idVehiculos,
          data.LlantasVehiculosNoQuemado,
          data.LlantasVehiculosPresion,
          data.LlantasVehiculosPrecio,
          data.LlantasVehiculosPiso,
          data.LlantasVehiculosMM1,
          data.LlantasVehiculosMM2,
          data.LlantasVehiculosMM3,
          data.LlantasVehiculosMM4
        ]
      );
      results.push({ id: result.insertId });
      } catch (error) {
      errors.push({ error: error.message, data });
    }
  }
  if (errors.length > 0) {
    return res.status(207).json({ message: 'Algunas llantas no se guardaron', results, errors });
  }
  res.status(201).json({ message: 'Todas las llantas guardadas', results });
});

// PUT/UPDATE a llanta vehiculo
router.put('/:id', async (req, res) => {
  try {
    const { 
      Llantas_idLlantas,
      Vehiculos_idVehiculos,
      LlantasVehiculosNoQuemado,
      LlantasVehiculosPresion,
      LlantasVehiculosPrecio,
      LlantasVehiculosPiso
    } = req.body;
    
    const [result] = await db.query(
      `UPDATE LlantasVehiculos SET 
        Llantas_idLlantas = ?,
        Vehiculos_idVehiculos = ?,
        LlantasVehiculosNoQuemado = ?,
        LlantasVehiculosPresion = ?,
        LlantasVehiculosPrecio = ?,
        LlantasVehiculosPiso = ?
      WHERE idLlantasVehiculos = ?`,
      [
        Llantas_idLlantas,
        Vehiculos_idVehiculos,
        LlantasVehiculosNoQuemado,
        LlantasVehiculosPresion,
        LlantasVehiculosPrecio,
        LlantasVehiculosPiso,
        req.params.id
      ]
    );
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Llanta de vehículo no encontrada' });
    }
    
    res.json({ message: 'Llanta del vehículo actualizada correctamente' });
  } catch (error) {
    handleServerError(res, 'Error al actualizar la llanta del vehículo', error);
  }
});

// DELETE a llanta vehiculo
router.delete('/:id', async (req, res) => {
  try {
    const [result] = await db.query('DELETE FROM LlantasVehiculos WHERE idLlantasVehiculos = ?', [req.params.id]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Llanta de vehículo no encontrada' });
    }
    
    res.json({ message: 'Llanta del vehículo eliminada correctamente' });
  } catch (error) {
    handleServerError(res, 'Error al eliminar la llanta del vehículo', error);
  }
});

module.exports = router;
